Name: Mohammed Sajid
matrikulation number: 3171311

Guess the Number Game

Purpose
This Python software generates a random number between 1 and 100 and asks the user to predict it. The software will tell the user whether the guess was too high or too low and keep track of how many attempts it took the user to get it right. Also, the user can quit the game at anytime.

Requirements and Dependencies
Python 3.11.2. 
random library should be imported to run the program here

Installation and Setup
Clone the repository or download the source code.
Install Python 3.11.2. if not already installed.
Install any required IDE to run the code such as PyCharm, Visual Studio Code, or IDLE.
Run the program from the command line.

Usage
You will be asked to guess the number between 1 and 100, or you are given a chance to quit the game by pressing 'q'. By pressing 'q' you will exit the game.
Once given a number input the program will tell if the guessed number is the same number guessed by the machine, if not you will be asked to try again by giving you a clue whether the guessed number by the user is higher or lower to the number guessed by the machine. Once the user guess the number correctly the program tells in how many number of guesses the user got the guess correct.


Contributing
This is a very simple program of guessing the number by using a function to generate a random number and a loop till the user guesses the correct number. 
